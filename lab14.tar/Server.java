import java.io.*;
import java.net.*;
import java.time.*;
import java.util.ArrayList;

public class Server {

    private int port;
    private ServerSocket serverSocket;
    private ArrayList<Socket> clients = new ArrayList<>();
    private ArrayList<LocalDateTime> connectedTimes = new ArrayList<>();

    public Server(int port) throws Exception {
        this.port = port;
        serverSocket = new ServerSocket(port);
    }

    public void serve(int num) {
        try {
            for (int i = 0; i < num; i++) {

                Socket s = serverSocket.accept();
                clients.add(s);

                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                PrintWriter out = new PrintWriter(s.getOutputStream());

                String handshake = in.readLine();

                // handshake must be exactly 12345
                if (!"12345".equals(handshake)) {
                    out.println("couldn't handshake");
                    out.flush();
                    s.close();
                    continue;
                }

                // correct handshake response (tester expects this)
                out.println("12345");
                out.flush();

                // record time of connection
                connectedTimes.add(LocalDateTime.now());

                // process one request
                try {
                    String numString = in.readLine();
                    long n = Long.parseLong(numString);

                    long factors = countFactors(n);

                    out.println("The number " + n + " has " + factors + " factors");
                    out.flush();

                } catch (Exception e) {
                    out.println("There was an exception on the server");
                    out.flush();
                }
            }
        } catch (Exception e) {
        }
    }

    private long countFactors(long n) {
        long count = 0;
        long limit = (long) Math.sqrt(n);

        for (long i = 1; i <= limit; i++) {
            if (n % i == 0) {
                count += 2;
            }
        }
        if (limit * limit == n)
            count--; // perfect square adjustment
        return count;
    }

    public ArrayList<LocalDateTime> getConnectedTimes() {
        return connectedTimes;
    }

    public void disconnect() {
        try {
            serverSocket.close();
        } catch (Exception e) {
        }
        for (Socket s : clients) {
            try {
                s.close();
            } catch (Exception e) {
            }
        }
    }
}
